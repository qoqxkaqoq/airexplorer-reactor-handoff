Krypton v1.0.0 - .NET Reactor devirtualizer (Release build, win-x64)

Usage:
  Krypton.exe <input-assembly.exe> --no-pause

or drag & drop a target .exe/.dll onto Krypton.exe.

Krypton.Runner.exe is the isolated net48 sandbox host used for runtime
capture/validation; keep it in the same folder as Krypton.exe.

Full documentation, source, and changelog:
https://github.com/dawwinci/krypton-devirtualizer
